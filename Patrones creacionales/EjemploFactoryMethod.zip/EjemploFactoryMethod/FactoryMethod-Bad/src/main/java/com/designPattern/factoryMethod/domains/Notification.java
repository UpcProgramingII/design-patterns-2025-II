package com.designPattern.factoryMethod.domains;

public interface Notification {
    String send(String message);
}
