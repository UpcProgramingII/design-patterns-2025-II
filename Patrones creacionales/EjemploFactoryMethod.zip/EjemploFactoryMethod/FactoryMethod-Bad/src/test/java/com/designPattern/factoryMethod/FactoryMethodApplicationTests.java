package com.designPattern.factoryMethod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FactoryMethodApplicationTests {

	@Test
	void contextLoads() {
	}

}
