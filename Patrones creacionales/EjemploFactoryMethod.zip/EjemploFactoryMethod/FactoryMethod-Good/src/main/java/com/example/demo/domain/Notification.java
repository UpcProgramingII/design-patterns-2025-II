package com.example.demo.domain;

public interface Notification {

    String send(String msg);

}
