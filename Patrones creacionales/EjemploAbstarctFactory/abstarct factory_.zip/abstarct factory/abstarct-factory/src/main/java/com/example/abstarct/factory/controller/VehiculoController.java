package com.example.abstarct.factory.controller;

import com.example.abstarct.factory.domain.IAutomovil;
import com.example.abstarct.factory.domain.IScooter;
import com.example.abstarct.factory.service.VehiculoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VehiculoController {

    @Autowired
    private VehiculoService service;

    @GetMapping("/config")
    public String configApp(@RequestParam String type){
        return this.service.configProvider(type);
    }

    @GetMapping("/scooter")
    public String getScooter(){
        IScooter scooter = service.getScooter();
        return scooter.getInfoScooter();
    }

    @GetMapping("/auto")
    public String getAutomovil(){

        IAutomovil auto = service.getAutomovil();
        return auto.getInfoAutomovil();

    }

}
