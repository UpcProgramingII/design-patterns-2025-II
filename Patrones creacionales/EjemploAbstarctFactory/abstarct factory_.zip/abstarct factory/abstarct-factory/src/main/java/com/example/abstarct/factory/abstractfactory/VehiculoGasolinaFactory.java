package com.example.abstarct.factory.abstractfactory;

import com.example.abstarct.factory.domain.AutomovilGasolina;
import com.example.abstarct.factory.domain.IAutomovil;
import com.example.abstarct.factory.domain.IScooter;
import com.example.abstarct.factory.domain.ScooterGasolina;
import org.springframework.stereotype.Component;

@Component
public class VehiculoGasolinaFactory implements VehiculoFactory{

    @Override
    public IScooter createScooter() {
        return new ScooterGasolina(40);
    }

    @Override
    public IAutomovil createAutomovil() {
        return new AutomovilGasolina(80);
    }

}
