package com.example.abstarct.factory.domain;

public class ScooterGasolina implements IScooter{

    private double capacidadTanque;

    public ScooterGasolina(double capacidadTanque) {
        this.capacidadTanque = capacidadTanque;
    }

    public double getCapacidadTanque() {
        return capacidadTanque;
    }

    public void setCapacidadTanque(double capacidadTanque) {
        this.capacidadTanque = capacidadTanque;
    }

    @Override
    public String getInfoScooter() {
        return "Ha seleccionado una scooter gasolina con " +
                "capacidad de:  "+this.capacidadTanque + " Gal";
    }
}
