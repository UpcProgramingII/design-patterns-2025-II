package com.example.abstarct.factory.abstractfactory;

import com.example.abstarct.factory.domain.IAutomovil;
import com.example.abstarct.factory.domain.IScooter;

public interface VehiculoFactory {

    IScooter createScooter();
    IAutomovil createAutomovil();

}
