package com.example.abstarct.factory.service;

import com.example.abstarct.factory.abstractfactory.FactoryProvider;
import com.example.abstarct.factory.abstractfactory.VehiculoFactory;
import com.example.abstarct.factory.domain.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehiculoService {

    private FactoryProvider provider;
    private VehiculoFactory factory;

    @Autowired
    public VehiculoService(FactoryProvider provider) {
        this.provider = provider;
    }

    public IScooter getScooter(){

        this.factory = this.provider.getFactory();
        return factory.createScooter();

    }


    public IAutomovil getAutomovil(){

        this.factory = this.provider.getFactory();
        return factory.createAutomovil();

    }

    public String configProvider(String type){
        this.provider.setCurrentType(type);
        return "Aplicacion configurada para  "+type;
    }

}
