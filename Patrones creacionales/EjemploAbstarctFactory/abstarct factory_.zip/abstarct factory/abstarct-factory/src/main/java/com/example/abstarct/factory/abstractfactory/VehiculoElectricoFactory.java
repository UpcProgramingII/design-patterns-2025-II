package com.example.abstarct.factory.abstractfactory;

import com.example.abstarct.factory.domain.AutomovilElectrico;
import com.example.abstarct.factory.domain.IAutomovil;
import com.example.abstarct.factory.domain.IScooter;
import com.example.abstarct.factory.domain.ScooterElectrica;
import org.springframework.stereotype.Component;

@Component
public class VehiculoElectricoFactory implements VehiculoFactory{
    @Override
    public IScooter createScooter() {
        return new ScooterElectrica(100);
    }

    @Override
    public IAutomovil createAutomovil() {
        return new AutomovilElectrico(800);
    }
}
