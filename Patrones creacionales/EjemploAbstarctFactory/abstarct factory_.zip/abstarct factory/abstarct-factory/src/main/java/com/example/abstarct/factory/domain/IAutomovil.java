package com.example.abstarct.factory.domain;

public interface IAutomovil {

    String getInfoAutomovil();

}
