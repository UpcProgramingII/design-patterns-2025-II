package com.example.abstarct.factory.domain;

public class AutomovilElectrico implements IAutomovil{

    private double autonomiaKms;

    public AutomovilElectrico(double autonomiaKms) {
        this.autonomiaKms = autonomiaKms;
    }

    public double getAutonomiaKms() {
        return autonomiaKms;
    }

    public void setAutonomiaKms(double autonomiaKms) {
        this.autonomiaKms = autonomiaKms;
    }

    @Override
    public String getInfoAutomovil() {
        return "Ha seleccionado una automovil electrico con " +
                "autonomia de:  "+this.autonomiaKms + " kms";
    }
}
