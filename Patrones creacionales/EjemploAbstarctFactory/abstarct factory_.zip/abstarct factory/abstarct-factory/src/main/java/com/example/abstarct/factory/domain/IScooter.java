package com.example.abstarct.factory.domain;

public interface IScooter {

    String getInfoScooter();

}
