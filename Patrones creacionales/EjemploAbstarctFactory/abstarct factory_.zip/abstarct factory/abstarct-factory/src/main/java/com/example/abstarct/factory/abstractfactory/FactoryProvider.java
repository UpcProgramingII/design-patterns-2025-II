package com.example.abstarct.factory.abstractfactory;

import com.example.abstarct.factory.domain.ScooterElectrica;
import com.example.abstarct.factory.domain.ScooterGasolina;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FactoryProvider {

    private VehiculoElectricoFactory factoryElectrico;
    private VehiculoGasolinaFactory factoryGasolina;
    private String currentType;

    @Autowired
    public FactoryProvider(VehiculoElectricoFactory factoryElectrico, VehiculoGasolinaFactory factoryGasolina) {
        this.factoryElectrico = factoryElectrico;
        this.factoryGasolina = factoryGasolina;
    }

    public String getCurrentType() {
        return currentType;
    }

    public void setCurrentType(String currentType) {
        this.currentType = currentType;
    }

    public VehiculoFactory getFactory(){

        if(this.currentType.equals("electrico")){
            return this.factoryElectrico;
        }else{
            return this.factoryGasolina;
        }

    }
}
