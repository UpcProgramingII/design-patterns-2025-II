package com.example.abstarct.factory.domain;

public class ScooterElectrica implements IScooter{

    private double autonomiaKms;

    public ScooterElectrica(double autonomiaKms) {
        this.autonomiaKms = autonomiaKms;
    }

    public double getAutonomiaKms() {
        return autonomiaKms;
    }

    public void setAutonomiaKms(double autonomiaKms) {
        this.autonomiaKms = autonomiaKms;
    }

    @Override
    public String getInfoScooter() {
        return "Ha seleccionado una scooter electrica con " +
                "autonomia de:  "+this.autonomiaKms + " kms";
    }


}
