package com.example.abstarct.factory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbstarctFactoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbstarctFactoryApplication.class, args);
	}

}
