package com.example.abstarct.factory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbstarctFactoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
